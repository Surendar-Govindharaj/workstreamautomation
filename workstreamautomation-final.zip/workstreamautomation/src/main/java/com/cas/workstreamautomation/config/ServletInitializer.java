package com.cas.workstreamautomation.config;

import com.cas.workstreamautomation.WorkstreamautomationApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

public class ServletInitializer extends SpringBootServletInitializer {

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		return application.sources(WorkstreamautomationApplication.class);
	}

}
