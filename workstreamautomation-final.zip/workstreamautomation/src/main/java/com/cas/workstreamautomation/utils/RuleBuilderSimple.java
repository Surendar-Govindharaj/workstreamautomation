package com.cas.workstreamautomation.utils;
import lombok.extern.slf4j.Slf4j;

import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class RuleBuilderSimple {
    private static final String AND_TEMPLATE = "{\"missing\":[%s]}";
    private static final String OR_TEMPLATE = "{\"missing_some\":[1,[%s]]}";
    private static final String IF_TEMPLATE = "{\"if\":[%s,%s,\"OK\"]}";

    public static String buildRule(String input) {
        log.info("Started Building Rule for {}", input);
        input = input.replace("'", "|").replace(" ", "");
        log.info("Replaced ' with | and removed spaces => : {}", input);
        // Handle Parentheses
        if (input.contains("(")) {
            log.info("Case 1 : Started with paranthesis case for input => {}", input);
            int start = input.indexOf('(');
            int end = input.lastIndexOf(')');
            String before = input.substring(0, start);
            String inside = input.substring(start + 1, end);
            String after="";
            if(input.length()-1>end){
                after=input.substring(end+1,input.length());
            }

            if(!before.trim().isEmpty()){
                log.info("Case 1 : Building rule for inside paranthesis => {}",inside);
                String left = buildRule(inside);
                log.info("Case 1 : Building rule for before paranthesis => {}", before);
                String right = buildRule(before.replace("|", "").replace("'", ""));
                String pOp=String.format(IF_TEMPLATE, right, left);
                log.info("Case 1 Building completed for input {} and rule is => {}", input, pOp);
                return pOp;
            }
            if(!after.trim().isEmpty()){
                log.info("Case 1 : Building rule for inside paranthesis => {}", inside);
                String  right= buildRule(inside);
                log.info("Case 1 : Building rule for after paranthesis => {}", inside);
                String  left= buildRule(after.replace("|", "").replace("'", ""));
                String afterPop=String.format(IF_TEMPLATE, right, left);
                log.info("Case 1 Building completed for input {} and rule is=> {}", input, afterPop);
                return afterPop;
            }
        }

        // Mixed AND + OR
        if ((input.contains("&") || input.contains(",")) && input.contains("|")) {
            log.info("Case 2: Started with Mixed AND and OR for input => {}", input);
            int andOperator=0;
            int orOperator=0;
            String operator="";
            andOperator=input.indexOf("&")>input.indexOf(",")?input.indexOf("&"):input.indexOf(",");
            orOperator=input.indexOf("|");
            operator=orOperator>andOperator?"\\|": "[&,]";
            log.info("Case 2: Splitting {} by the operator  => {}", input, operator);
            String[] parts = input.split(operator, 2);
            parts[1]=orOperator>andOperator?parts[1]:"&"+parts[1];
            log.info("Case 2: Building rule for left half  => {}",parts[0]);
            String left = buildRule(parts[0]);
            log.info("Case 2: Building rule for right half  => {}",parts[1]);
            String right = buildRule(parts[1]);
            String mixedOp=String.format(IF_TEMPLATE, left, right);
            log.info("Case 2: Building completed for {} ,rule is => {}", input, mixedOp);
            return mixedOp;
        }

        // AND logic
        if (input.contains("&") || input.contains(",")) {
            return buildAnd(input);
        }

        // OR logic
        return buildOr(input);
    }

        private static String buildAnd(String expr) {
            log.info("Case 3 : Started for Simple AND Logic for input => {}",expr);
            String[] items = expr.split("[&,]");
            log.info("AND : Splitted with AND Logic => {}", (Object) items);
            String andOp=String.format(AND_TEMPLATE, quoteItems(items));
            log.info("AND : Builded Rule for AND Logic for input => {} and rule is {}",expr,andOp);
            return andOp;
        }

        private static String buildOr(String expr) {
            log.info("Case 4 : Started for Simple OR Logic for input => {}",expr);
            String[] items = expr.split("\\|");
            log.info("OR : Splitted with OR Logic => {}", (Object) items);
            List<String> list = new ArrayList<>(Arrays.asList(items));
            list.add("dummy");
            log.info("OR : Added DUMMY for OR Logic => {}",list);
            String orOP=String.format(OR_TEMPLATE, quoteItems(list.toArray(new String[0])));
            log.info("OR : Builded Rule for OR Logic for input => {} and rule is {}",expr,orOP);
            return orOP;
        }

        private static String quoteItems(String[] items) {
            String op="";
            log.info("AND | OR : Adding Quotes - quoteitems method input => {}", (Object) items);
            op= Arrays.stream(items)
                    .filter(s -> !s.isEmpty())
                    .map(s -> "\"" + s + "\"")
                    .collect(Collectors.joining(","));
            log.info("AND | OR : Adding Quotes - quoteitems method output => {}",op);
            return op;
        }
}
