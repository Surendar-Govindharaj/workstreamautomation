package com.cas.workstreamautomation.ewn;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.Optional;

@RequestMapping("/ewnUploadFile")
@RestController
public class EWNAutomationController {

    @Autowired
    EWNAutomationService ewnAutomationService;

    @PostMapping(value="/uploadInputFile", consumes = MediaType.MULTIPART_FORM_DATA_VALUE,produces = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity generateEwnOutputFile(@RequestPart("upload-file-here") MultipartFile file){

        if (file.isEmpty() || !file.getOriginalFilename().toLowerCase().endsWith(".xlsx")) {
            return ResponseEntity.badRequest().body("Only .xls files are allowed.");
        }
        String opFileName= file.getOriginalFilename().replace("Input","Output").replace("input","Output");
        byte[] modifiedBytes= null;
        try {
            modifiedBytes = ewnAutomationService.getOutputFile(file);
            if(Optional.ofNullable(modifiedBytes).isEmpty()){
                return ResponseEntity.badRequest().body("Error occured while processing the file");
            }
            return ResponseEntity.ok()
                    .contentType(MediaType.APPLICATION_OCTET_STREAM)
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+opFileName)
                    .body(modifiedBytes);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Exception Occured while building rules with error as : "+e.getMessage());
        }

    }

}
