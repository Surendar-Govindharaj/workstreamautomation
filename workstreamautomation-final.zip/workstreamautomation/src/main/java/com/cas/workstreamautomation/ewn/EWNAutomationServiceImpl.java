package com.cas.workstreamautomation.ewn;


import com.cas.workstreamautomation.utils.RuleBuilderSimple;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

@Service
@Slf4j
public class EWNAutomationServiceImpl implements EWNAutomationService {


    @Override
    public byte[] getOutputFile(MultipartFile file) throws Exception {
        byte[] opBytes=null;
        try{
            if(!file.isEmpty() && opBytes==null){
                log.info("Loading the original workbook from input");
                Workbook originalWorkbook = new XSSFWorkbook(file.getInputStream());
                log.info("Creating a copy of the workbook");
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                originalWorkbook.write(outputStream);
                originalWorkbook.close();
                log.info("Reload copied workbook from the stream");
                InputStream copiedInput = new ByteArrayInputStream(outputStream.toByteArray());
                Workbook copiedWorkbook = new XSSFWorkbook(copiedInput);
                log.info("Getting sheet from the workbook");
                Sheet sheet = copiedWorkbook.getSheetAt(0);

                for (Row row : sheet) {
                    if(row.getRowNum()==0){
                        Cell headSecondCell= row.createCell(2);
                        log.info("Creating new column as 'Rules'");
                        headSecondCell.setCellValue("Rules");
                        continue;
                    }
                    Cell cell = row.getCell(1);
                    if (cell != null && cell.getStringCellValue()!=null && !cell.getStringCellValue().trim().isEmpty()) {
                        log.info("Fetched the Required Task : {}",cell.getStringCellValue());
                        log.info("****** RULE BUILDING STARTED for {} ********", cell.getStringCellValue());
                        String rule= RuleBuilderSimple.buildRule(cell.getStringCellValue());
                        log.info("****** RULE BUILDING ENDED for {} ********", cell.getStringCellValue());
                        Cell secondcell= row.createCell(2);
                        secondcell.setCellValue(rule);
                        log.info("Created and updated new cell for the Rule : {}", rule);
                        log.info("OUTPUT : {} : {}",cell.getStringCellValue(),rule);
                    }
                    else{
                        continue;
                    }
                }


                // Step 4: Write the modified file to byte array
                ByteArrayOutputStream modifiedOutput = new ByteArrayOutputStream();
                copiedWorkbook.write(modifiedOutput);
                copiedWorkbook.close();

                opBytes = modifiedOutput.toByteArray();





            }

        }catch(Exception e){
            e.printStackTrace();
        }


        return opBytes;
    }
}
