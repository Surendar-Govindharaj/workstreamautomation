package com.cas.workstreamautomation.ewn;

import org.springframework.stereotype.Repository;

//@Repository
public interface EWNAutomationRepository {
}
