package com.cas.workstreamautomation.ewn;

import org.springframework.web.multipart.MultipartFile;

public interface EWNAutomationService {
    public byte[] getOutputFile(MultipartFile file) throws Exception;
}
