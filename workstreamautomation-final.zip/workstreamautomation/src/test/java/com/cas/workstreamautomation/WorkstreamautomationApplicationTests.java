package com.cas.workstreamautomation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkstreamautomationApplicationTests {

	@Test
	void contextLoads() {
	}

}
